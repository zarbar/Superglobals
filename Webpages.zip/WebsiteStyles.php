
 .navbar{
       width: 100%;
       text-align: center;
       size: 100px; 
       
        }
    
 
.bodycolour {
 
    background-color:pink;
    background-image:linear-gradient(to right,#ffccff,white);
 }
 
 .containerccolour {
     
    color: black;
    background-color:pink;
    background-image:linear-gradient(to right,#ffccff,white);
 }
 
     
     
 